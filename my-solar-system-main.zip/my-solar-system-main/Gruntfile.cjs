// Copyright 2020, University of Colorado Boulder


// use chipper's gruntfile
module.exports = require( '../chipper/js/grunt/commonjs/gruntMain.js' );